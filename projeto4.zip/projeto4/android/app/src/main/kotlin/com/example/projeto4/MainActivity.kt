package com.example.projeto4

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
